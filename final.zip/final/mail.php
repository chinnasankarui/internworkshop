<?php
  
    ini_set('display_errors', '1');
    ini_set('display_startup_errors', '1');
    error_reporting(E_ALL);

  $name = $_POST['name'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $message = $_POST['message'];


  $to = 'info@internworkshop.com';
  $subject = " Mail From Website";

  $txt = "Name = ' . $name . '\r\n Email = '. $email . '\r\n  Phone = ' . $phone . '\r\n Message = " . $message;

  $headers = "info@internworkshop.com";
  if($name!=NULL){
    mail($to, $subject, $txt,  $headers);
  }

  header("Location: thankyou.html")

?>